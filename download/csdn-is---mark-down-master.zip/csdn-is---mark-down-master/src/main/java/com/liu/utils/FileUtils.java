package com.liu.utils;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

public class FileUtils {

    public static final String IMAGE_DIR = "images"+ File.separator;


    /**
     * 下载图片到本地
     * @param imageSrc
     * @return
     */
    public static String downloadImage(String imageSrc){
//        String fileExtension = getImageExtension(imageSrc);
        String fileExtension = ".png";
        String uniqueFileName = System.currentTimeMillis() + fileExtension;

        // 在当前目录下创建一个名为"images"的目录
        Path imagesDir = Paths.get(IMAGE_DIR);
        if (!Files.exists(imagesDir)) {
            try {
                Files.createDirectories(imagesDir);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        // 定义图片保存的路径
        Path outputPath = imagesDir.resolve(uniqueFileName);

        try {
            // 打开网络连接
            URL url = new URL(imageSrc);
            // 使用NIO将数据从网络复制到文件，同时为文件生成一个唯一的名称
            Files.copy(url.openStream(), outputPath, StandardCopyOption.REPLACE_EXISTING);
            System.out.println("Image downloaded successfully: " + outputPath.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "../"+IMAGE_DIR + uniqueFileName;
    }

    private static String getImageExtension(String imageUrl) {
        // 获取查询参数前的URL部分
        String baseUrl = imageUrl.split("[\\?#]")[0];
        int lastIndexOfDot = baseUrl.lastIndexOf('.');
        return lastIndexOfDot == -1 ? "" : baseUrl.substring(lastIndexOfDot);
    }

    public static void main(String[] args) {
        String s = downloadImage("https://img-blog.csdnimg.cn/img_convert/7aeebffe733955f1b7e9a9a1d4ed0a85.png#averageHue=#fdfdfc&clientId=ua5af58b4-5671-4&from=paste&height=462&id=ud84593f4&name=image.png&originHeight=712&originWidth=1045&originalType=binary&ratio=1.25&rotation=0&showTitle=false&size=88274&status=done&style=shadow&taskId=u8a3d1365-87c4-4ce9-87ce-49041716394&title=&width=677.4000244140625");
        System.out.println(s);
    }
}
